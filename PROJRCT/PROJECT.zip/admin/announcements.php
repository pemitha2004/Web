<?php
include "../config.php";
include "check.php";

$edit_id = (int)($_GET["edit"] ?? 0);
$edit_title = "";
$edit_message = "";

/* Delete */
if (isset($_GET["delete"])) {
    $id = (int)$_GET["delete"];

    $conn->query(
        "DELETE FROM announcements WHERE id = $id"
    );

    header("Location: announcements.php");
    exit;
}

/* Add or update */
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = (int)$_POST["id"];
    $title = trim($_POST["title"]);
    $message = trim($_POST["message"]);

    if ($id == 0) {
        $stmt = $conn->prepare(
            "INSERT INTO announcements
             (title, message)
             VALUES (?, ?)"
        );

        $stmt->bind_param(
            "ss",
            $title,
            $message
        );
    } else {
        $stmt = $conn->prepare(
            "UPDATE announcements
             SET title = ?, message = ?
             WHERE id = ?"
        );

        $stmt->bind_param(
            "ssi",
            $title,
            $message,
            $id
        );
    }

    $stmt->execute();

    header("Location: announcements.php");
    exit;
}

/* Load announcement for editing */
if ($edit_id > 0) {
    $row = $conn->query(
        "SELECT *
         FROM announcements
         WHERE id = $edit_id"
    )->fetch_assoc();

    $edit_title = $row["title"] ?? "";
    $edit_message = $row["message"] ?? "";
}

$announcements = $conn->query(
    "SELECT *
     FROM announcements
     ORDER BY published_at DESC"
);

$page_title = "Announcements";
include "header.php";
?>

<section class="eventSection">
    <div class="wrap">
        <div class="sectionTop">
            <div>
                <span class="tag">Announcements</span>
                <h2>Manage Announcements</h2>

                <p class="gray">
                    Add, edit or delete student updates.
                </p>
            </div>
        </div>

        <div class="infoBox formGap">
            <form method="post">
                <input
                    type="hidden"
                    name="id"
                    value="<?php echo $edit_id; ?>"
                >

                <div class="inputBox">
                    <label>Title</label>

                    <input
                        type="text"
                        name="title"
                        value="<?php
                        echo htmlspecialchars($edit_title);
                        ?>"
                        required
                    >
                </div>

                <div class="inputBox">
                    <label>Message</label>

                    <textarea
                        name="message"
                        required
                    ><?php
                    echo htmlspecialchars(
                        $edit_message
                    );
                    ?></textarea>
                </div>

                <button class="btn">
                    <?php
                    echo $edit_id
                        ? "Save Changes"
                        : "Publish";
                    ?>
                </button>
            </form>
        </div>

        <div class="tableArea">
            <table>
                <tr>
                    <th>Title</th>
                    <th>Date</th>
                    <th>Actions</th>
                </tr>

                <?php while ($item = $announcements->fetch_assoc()) { ?>
                    <tr>
                        <td>
                            <?php
                            echo htmlspecialchars(
                                $item["title"]
                            );
                            ?>
                        </td>

                        <td>
                            <?php
                            echo $item["published_at"];
                            ?>
                        </td>

                        <td>
                            <div class="tableButtons">
                                <a
                                    href="announcements.php?edit=<?php echo $item["id"]; ?>"
                                    class="btn btnLight btnSmall"
                                >
                                    Edit
                                </a>

                                <a
                                    href="announcements.php?delete=<?php echo $item["id"]; ?>"
                                    class="btn btnRed btnSmall"
                                    onclick="return confirmDelete();"
                                >
                                    Delete
                                </a>
                            </div>
                        </td>
                    </tr>
                <?php } ?>
            </table>
        </div>
    </div>
</section>

<?php include "footer.php"; ?>
