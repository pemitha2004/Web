<?php
include "../config.php";
include "check.php";

$edit_id = (int)($_GET["edit"] ?? 0);

/* Delete event */
if (isset($_GET["delete"])) {
    $id = (int)$_GET["delete"];

    $conn->query(
        "DELETE FROM events WHERE id = $id"
    );

    header("Location: events.php");
    exit;
}

/* Add or update event */
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = (int)$_POST["id"];
    $category = (int)$_POST["category"];
    $title = trim($_POST["title"]);
    $description = trim($_POST["description"]);
    $date = $_POST["date"];
    $time = $_POST["time"];
    $venue = trim($_POST["venue"]);
    $capacity = (int)$_POST["capacity"];
    $status = $_POST["status"];

    if ($id == 0) {
        $stmt = $conn->prepare(
            "INSERT INTO events
             (
                category_id,
                title,
                description,
                event_date,
                start_time,
                venue,
                capacity,
                status
             )
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
        );

        $stmt->bind_param(
            "isssssis",
            $category,
            $title,
            $description,
            $date,
            $time,
            $venue,
            $capacity,
            $status
        );
    } else {
        $stmt = $conn->prepare(
            "UPDATE events
             SET category_id = ?,
                 title = ?,
                 description = ?,
                 event_date = ?,
                 start_time = ?,
                 venue = ?,
                 capacity = ?,
                 status = ?
             WHERE id = ?"
        );

        $stmt->bind_param(
            "isssssisi",
            $category,
            $title,
            $description,
            $date,
            $time,
            $venue,
            $capacity,
            $status,
            $id
        );
    }

    $stmt->execute();

    header("Location: events.php");
    exit;
}

/* Empty form */
$edit = [
    "id" => 0,
    "title" => "",
    "category_id" => 1,
    "description" => "",
    "event_date" => "",
    "start_time" => "",
    "venue" => "",
    "capacity" => 100,
    "status" => "Published"
];

/* Load event for editing */
if ($edit_id > 0) {
    $edit = $conn->query(
        "SELECT * FROM events WHERE id = $edit_id"
    )->fetch_assoc();
}

$categories = $conn->query(
    "SELECT * FROM categories ORDER BY name"
);

$events = $conn->query(
    "SELECT events.*, categories.name AS category_name
     FROM events
     LEFT JOIN categories
     ON events.category_id = categories.id
     ORDER BY events.event_date DESC"
);

$page_title = "Manage Events";
include "header.php";
?>

<section class="eventSection">
    <div class="wrap">
        <div class="sectionTop">
            <div>
                <span class="tag">Events</span>
                <h2>Manage Events</h2>
                <p class="gray">
                    Add, edit or remove university events.
                </p>
            </div>
        </div>

        <div class="infoBox formGap">
            <h3>
                <?php
                echo $edit["id"]
                    ? "Edit Event"
                    : "Add New Event";
                ?>
            </h3>

            <form method="post">
                <input
                    type="hidden"
                    name="id"
                    value="<?php echo $edit["id"]; ?>"
                >

                <div class="twoInputs">
                    <div class="inputBox">
                        <label>Title</label>

                        <input
                            type="text"
                            name="title"
                            value="<?php
                            echo htmlspecialchars(
                                $edit["title"]
                            );
                            ?>"
                            required
                        >
                    </div>

                    <div class="inputBox">
                        <label>Category</label>

                        <select name="category">
                            <?php
                            while (
                                $cat = $categories->fetch_assoc()
                            ) {
                            ?>
                                <option
                                    value="<?php echo $cat["id"]; ?>"
                                    <?php
                                    if (
                                        $edit["category_id"]
                                        == $cat["id"]
                                    ) {
                                        echo "selected";
                                    }
                                    ?>
                                >
                                    <?php
                                    echo htmlspecialchars(
                                        $cat["name"]
                                    );
                                    ?>
                                </option>
                            <?php } ?>
                        </select>
                    </div>
                </div>

                <div class="inputBox">
                    <label>Description</label>

                    <textarea
                        name="description"
                        required
                    ><?php
                    echo htmlspecialchars(
                        $edit["description"]
                    );
                    ?></textarea>
                </div>

                <div class="twoInputs">
                    <div class="inputBox">
                        <label>Date</label>

                        <input
                            type="date"
                            name="date"
                            value="<?php
                            echo $edit["event_date"];
                            ?>"
                            required
                        >
                    </div>

                    <div class="inputBox">
                        <label>Time</label>

                        <input
                            type="time"
                            name="time"
                            value="<?php
                            echo substr(
                                $edit["start_time"],
                                0,
                                5
                            );
                            ?>"
                            required
                        >
                    </div>
                </div>

                <div class="twoInputs">
                    <div class="inputBox">
                        <label>Venue</label>

                        <input
                            type="text"
                            name="venue"
                            value="<?php
                            echo htmlspecialchars(
                                $edit["venue"]
                            );
                            ?>"
                            required
                        >
                    </div>

                    <div class="inputBox">
                        <label>Capacity</label>

                        <input
                            type="number"
                            name="capacity"
                            min="1"
                            value="<?php
                            echo $edit["capacity"];
                            ?>"
                            required
                        >
                    </div>
                </div>

                <div class="inputBox">
                    <label>Status</label>

                    <select name="status">
                        <?php
                        $statuses = [
                            "Published",
                            "Draft",
                            "Cancelled"
                        ];

                        foreach ($statuses as $status) {
                        ?>
                            <option
                                value="<?php echo $status; ?>"
                                <?php
                                if (
                                    $edit["status"] == $status
                                ) {
                                    echo "selected";
                                }
                                ?>
                            >
                                <?php echo $status; ?>
                            </option>
                        <?php } ?>
                    </select>
                </div>

                <button class="btn">
                    <?php
                    echo $edit["id"]
                        ? "Save Changes"
                        : "Add Event";
                    ?>
                </button>

                <?php if ($edit["id"]) { ?>
                    <a
                        href="events.php"
                        class="btn btnLight"
                    >
                        Cancel
                    </a>
                <?php } ?>
            </form>
        </div>

        <div class="tableArea">
            <table>
                <tr>
                    <th>Event</th>
                    <th>Category</th>
                    <th>Date</th>
                    <th>Venue</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>

                <?php while ($event = $events->fetch_assoc()) { ?>
                    <tr>
                        <td>
                            <?php
                            echo htmlspecialchars(
                                $event["title"]
                            );
                            ?>
                        </td>

                        <td>
                            <?php
                            echo htmlspecialchars(
                                $event["category_name"]
                                ?? "General"
                            );
                            ?>
                        </td>

                        <td>
                            <?php echo $event["event_date"]; ?>
                        </td>

                        <td>
                            <?php
                            echo htmlspecialchars(
                                $event["venue"]
                            );
                            ?>
                        </td>

                        <td>
                            <?php
                            echo htmlspecialchars(
                                $event["status"]
                            );
                            ?>
                        </td>

                        <td>
                            <div class="tableButtons">
                                <a
                                    href="events.php?edit=<?php echo $event["id"]; ?>"
                                    class="btn btnLight btnSmall"
                                >
                                    Edit
                                </a>

                                <a
                                    href="events.php?delete=<?php echo $event["id"]; ?>"
                                    class="btn btnRed btnSmall"
                                    onclick="return confirmDelete();"
                                >
                                    Delete
                                </a>
                            </div>
                        </td>
                    </tr>
                <?php } ?>
            </table>
        </div>
    </div>
</section>

<?php include "footer.php"; ?>
