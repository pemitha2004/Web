<?php
$page_title = $page_title ?? "EventHub Admin";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >
    <title><?php echo htmlspecialchars($page_title); ?></title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>

<header class="top adminTop">
    <div class="wrap nav">
        <a href="dashboard.php" class="brand">
            <span class="brandIcon">A</span>
            <span>EventHub Admin</span>
        </a>

        <button class="menuBtn" onclick="showMenu()">☰</button>

        <nav id="links">
            <a href="dashboard.php">Dashboard</a>
            <a href="events.php">Events</a>
            <a href="categories.php">Categories</a>
            <a href="registrations.php">Registrations</a>
            <a href="announcements.php">Announcements</a>
            <a href="../index.php">Student Site</a>
            <a href="../admin_logout.php">Logout</a>
        </nav>
    </div>
</header>

<main>
