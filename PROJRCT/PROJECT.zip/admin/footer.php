</main>

<footer class="footer">
    <div class="wrap footerRow">
        <div>
            <h3>EventHub Admin</h3>
            <p>Manage events, students and announcements.</p>
        </div>

        <div class="footerRight">
            <p>NSBM Green University</p>
        </div>
    </div>
</footer>

<script src="../js/script.js"></script>
</body>
</html>
