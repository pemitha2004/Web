<?php
include "../config.php";
include "check.php";

$event_count = $conn->query(
    "SELECT COUNT(*) AS total FROM events"
)->fetch_assoc()["total"];

$student_count = $conn->query(
    "SELECT COUNT(*) AS total FROM students"
)->fetch_assoc()["total"];

$join_count = $conn->query(
    "SELECT COUNT(*) AS total FROM registrations"
)->fetch_assoc()["total"];

$news_count = $conn->query(
    "SELECT COUNT(*) AS total FROM announcements"
)->fetch_assoc()["total"];

$page_title = "Admin Dashboard";
include "header.php";
?>

<section class="eventSection">
    <div class="wrap">
        <div class="sectionTop">
            <div>
                <span class="tag">Admin</span>

                <h2>
                    Welcome,
                    <?php
                    echo htmlspecialchars(
                        $_SESSION["admin_name"]
                    );
                    ?>
                </h2>

                <p class="gray">
                    Everything you need to manage EventHub is here.
                </p>
            </div>

            <a href="events.php" class="btn">
                + Add New Event
            </a>
        </div>

        <div class="numberRow">
            <div class="numberBox">
                <p>Events</p>
                <h2><?php echo $event_count; ?></h2>
            </div>

            <div class="numberBox">
                <p>Students</p>
                <h2><?php echo $student_count; ?></h2>
            </div>

            <div class="numberBox">
                <p>Registrations</p>
                <h2><?php echo $join_count; ?></h2>
            </div>

            <div class="numberBox">
                <p>Announcements</p>
                <h2><?php echo $news_count; ?></h2>
            </div>
        </div>

        <div class="adminButtons">
            <a href="events.php" class="btn">
                Manage Events
            </a>

            <a href="categories.php" class="btn btnLight">
                Categories
            </a>

            <a href="registrations.php" class="btn btnLight">
                Registrations
            </a>

            <a href="announcements.php" class="btn btnLight">
                Announcements
            </a>
        </div>
    </div>
</section>

<?php include "footer.php"; ?>
