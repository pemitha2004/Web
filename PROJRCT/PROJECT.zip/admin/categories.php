<?php
include "../config.php";
include "check.php";

$edit_id = (int)($_GET["edit"] ?? 0);
$edit_name = "";

/* Delete */
if (isset($_GET["delete"])) {
    $id = (int)$_GET["delete"];

    $conn->query(
        "DELETE FROM categories WHERE id = $id"
    );

    header("Location: categories.php");
    exit;
}

/* Add or update */
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = (int)$_POST["id"];
    $name = trim($_POST["name"]);

    if ($id == 0) {
        $stmt = $conn->prepare(
            "INSERT INTO categories (name)
             VALUES (?)"
        );

        $stmt->bind_param("s", $name);
    } else {
        $stmt = $conn->prepare(
            "UPDATE categories
             SET name = ?
             WHERE id = ?"
        );

        $stmt->bind_param("si", $name, $id);
    }

    $stmt->execute();

    header("Location: categories.php");
    exit;
}

/* Load edit value */
if ($edit_id > 0) {
    $row = $conn->query(
        "SELECT * FROM categories
         WHERE id = $edit_id"
    )->fetch_assoc();

    $edit_name = $row["name"] ?? "";
}

$categories = $conn->query(
    "SELECT * FROM categories ORDER BY name"
);

$page_title = "Categories";
include "header.php";
?>

<section class="eventSection">
    <div class="wrap">
        <div class="sectionTop">
            <div>
                <span class="tag">Categories</span>
                <h2>Manage Categories</h2>
                <p class="gray">
                    Add, edit or delete event categories.
                </p>
            </div>
        </div>

        <div class="infoBox formGap">
            <form method="post" class="smallForm">
                <input
                    type="hidden"
                    name="id"
                    value="<?php echo $edit_id; ?>"
                >

                <input
                    type="text"
                    name="name"
                    placeholder="Category name"
                    value="<?php
                    echo htmlspecialchars($edit_name);
                    ?>"
                    required
                >

                <button class="btn">
                    <?php
                    echo $edit_id
                        ? "Save Category"
                        : "Add Category";
                    ?>
                </button>
            </form>
        </div>

        <div class="tableArea">
            <table>
                <tr>
                    <th>Category</th>
                    <th>Actions</th>
                </tr>

                <?php while ($cat = $categories->fetch_assoc()) { ?>
                    <tr>
                        <td>
                            <?php
                            echo htmlspecialchars(
                                $cat["name"]
                            );
                            ?>
                        </td>

                        <td>
                            <div class="tableButtons">
                                <a
                                    href="categories.php?edit=<?php echo $cat["id"]; ?>"
                                    class="btn btnLight btnSmall"
                                >
                                    Edit
                                </a>

                                <a
                                    href="categories.php?delete=<?php echo $cat["id"]; ?>"
                                    class="btn btnRed btnSmall"
                                    onclick="return confirmDelete();"
                                >
                                    Delete
                                </a>
                            </div>
                        </td>
                    </tr>
                <?php } ?>
            </table>
        </div>
    </div>
</section>

<?php include "footer.php"; ?>
