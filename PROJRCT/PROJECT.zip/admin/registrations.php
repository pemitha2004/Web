<?php
include "../config.php";
include "check.php";

$event_id = (int)($_GET["event_id"] ?? 0);

/* Download participant list */
if (isset($_GET["export"]) && $event_id > 0) {
    $result = $conn->query(
        "SELECT students.name,
                students.email,
                registrations.registered_at
         FROM registrations
         JOIN students
         ON registrations.student_id = students.id
         WHERE registrations.event_id = $event_id
         ORDER BY students.name"
    );

    header("Content-Type: text/csv");
    header(
        "Content-Disposition:
         attachment; filename=participants.csv"
    );

    $file = fopen("php://output", "w");

    fputcsv(
        $file,
        ["Student Name", "Email", "Registered At"]
    );

    while ($row = $result->fetch_assoc()) {
        fputcsv(
            $file,
            [
                $row["name"],
                $row["email"],
                $row["registered_at"]
            ]
        );
    }

    fclose($file);
    exit;
}

$events = $conn->query(
    "SELECT id, title
     FROM events
     ORDER BY event_date DESC"
);

$sql = "
    SELECT students.name,
           students.email,
           events.title,
           events.event_date,
           registrations.registered_at
    FROM registrations
    JOIN students
    ON registrations.student_id = students.id
    JOIN events
    ON registrations.event_id = events.id
";

if ($event_id > 0) {
    $sql .= " WHERE events.id = $event_id";
}

$sql .= " ORDER BY registrations.registered_at DESC";

$rows = $conn->query($sql);

$page_title = "Registrations";
include "header.php";
?>

<section class="eventSection">
    <div class="wrap">
        <div class="sectionTop">
            <div>
                <span class="tag">Students</span>
                <h2>Event Registrations</h2>

                <p class="gray">
                    See which students joined each event.
                </p>
            </div>

            <?php if ($event_id > 0) { ?>
                <a
                    href="registrations.php?event_id=<?php
                    echo $event_id;
                    ?>&export=1"
                    class="btn"
                >
                    Download List
                </a>
            <?php } ?>
        </div>

        <form
            method="get"
            class="searchArea twoSearch"
        >
            <select name="event_id">
                <option value="0">All Events</option>

                <?php while ($event = $events->fetch_assoc()) { ?>
                    <option
                        value="<?php echo $event["id"]; ?>"
                        <?php
                        if ($event_id == $event["id"]) {
                            echo "selected";
                        }
                        ?>
                    >
                        <?php
                        echo htmlspecialchars(
                            $event["title"]
                        );
                        ?>
                    </option>
                <?php } ?>
            </select>

            <button class="btn">Filter</button>
        </form>

        <div class="tableArea">
            <table>
                <tr>
                    <th>Student</th>
                    <th>Email</th>
                    <th>Event</th>
                    <th>Date</th>
                    <th>Joined At</th>
                </tr>

                <?php while ($row = $rows->fetch_assoc()) { ?>
                    <tr>
                        <td>
                            <?php
                            echo htmlspecialchars(
                                $row["name"]
                            );
                            ?>
                        </td>

                        <td>
                            <?php
                            echo htmlspecialchars(
                                $row["email"]
                            );
                            ?>
                        </td>

                        <td>
                            <?php
                            echo htmlspecialchars(
                                $row["title"]
                            );
                            ?>
                        </td>

                        <td>
                            <?php echo $row["event_date"]; ?>
                        </td>

                        <td>
                            <?php
                            echo $row["registered_at"];
                            ?>
                        </td>
                    </tr>
                <?php } ?>
            </table>
        </div>
    </div>
</section>

<?php include "footer.php"; ?>
