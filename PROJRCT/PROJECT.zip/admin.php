<?php
include "config.php";

if (isset($_SESSION["admin_id"])) {
    header("Location: admin/dashboard.php");
    exit;
}

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST["email"]);
    $password = $_POST["password"];

    $stmt = $conn->prepare(
        "SELECT * FROM admins WHERE email = ?"
    );

    $stmt->bind_param("s", $email);
    $stmt->execute();

    $admin = $stmt->get_result()->fetch_assoc();

    if (
        $admin &&
        password_verify($password, $admin["password"])
    ) {
        $_SESSION["admin_id"] = $admin["id"];
        $_SESSION["admin_name"] = $admin["name"];

        header("Location: admin/dashboard.php");
        exit;
    }

    $message = "Admin email or password is incorrect.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >
    <title>Admin Login</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<header class="top">
    <div class="wrap nav">
        <a href="index.php" class="brand">
            <span class="brandIcon">E</span>
            <span>NSBM EventHub</span>
        </a>

        <nav id="links">
            <a href="index.php">Back to Student Site</a>
        </nav>
    </div>
</header>

<section class="adminLoginPage">
    <div class="adminLogin">
        <span class="tag">Admin Area</span>
        <h1>Admin Login</h1>

        <p class="gray">
            This page is only for EventHub administrators.
        </p>

        <?php if ($message != "") { ?>
            <div class="message error">
                <?php echo htmlspecialchars($message); ?>
            </div>
        <?php } ?>

        <form method="post">
            <div class="inputBox">
                <label>Admin Email</label>
                <input type="email" name="email" required>
            </div>

            <div class="inputBox">
                <label>Password</label>
                <input type="password" name="password" required>
            </div>

            <button class="btn">
                Login to Admin Panel
            </button>
        </form>
    </div>
</section>

</body>
</html>
