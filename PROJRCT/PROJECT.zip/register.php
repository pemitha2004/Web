<?php
include "config.php";

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = trim($_POST["name"]);
    $email = trim($_POST["email"]);
    $password = $_POST["password"];

    if ($name == "" || $email == "" || $password == "") {
        $message = "Please fill in all fields.";
    } else {
        $stmt = $conn->prepare(
            "SELECT id FROM students WHERE email = ?"
        );

        $stmt->bind_param("s", $email);
        $stmt->execute();

        if ($stmt->get_result()->num_rows > 0) {
            $message = "This email is already registered.";
        } else {
            $hash = password_hash(
                $password,
                PASSWORD_DEFAULT
            );

            $stmt = $conn->prepare(
                "INSERT INTO students
                 (name, email, password)
                 VALUES (?, ?, ?)"
            );

            $stmt->bind_param(
                "sss",
                $name,
                $email,
                $hash
            );

            if ($stmt->execute()) {
                header("Location: login.php?created=1");
                exit;
            }
        }
    }
}

$page_title = "Register";
include "header.php";
?>

<div class="wrap">
    <div class="formArea">
        <span class="tag">Student Account</span>
        <h2>Create Your Account</h2>

        <p class="gray">
            Sign up so you can join events
            and keep your own schedule.
        </p>

        <?php if ($message != "") { ?>
            <div class="message error">
                <?php echo htmlspecialchars($message); ?>
            </div>
        <?php } ?>

        <form method="post">
            <div class="inputBox">
                <label>Full Name</label>
                <input type="text" name="name" required>
            </div>

            <div class="inputBox">
                <label>Email Address</label>
                <input type="email" name="email" required>
            </div>

            <div class="inputBox">
                <label>Password</label>
                <input
                    type="password"
                    name="password"
                    minlength="6"
                    required
                >
            </div>

            <button class="btn">Register</button>
        </form>
    </div>
</div>

<?php include "footer.php"; ?>
