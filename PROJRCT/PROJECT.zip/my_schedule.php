<?php
include "config.php";

if (!isset($_SESSION["student_id"])) {
    header("Location: login.php");
    exit;
}

$student_id = $_SESSION["student_id"];

$events = $conn->query(
    "SELECT events.*, categories.name AS category_name
     FROM registrations
     JOIN events
     ON registrations.event_id = events.id
     LEFT JOIN categories
     ON events.category_id = categories.id
     WHERE registrations.student_id = $student_id
     ORDER BY events.event_date"
);

$page_title = "My Schedule";
include "header.php";
?>

<section class="eventSection">
    <div class="wrap">
        <div class="sectionTop">
            <div>
                <span class="tag">My Account</span>
                <h2>My Schedule</h2>

                <p class="gray">
                    Hi
                    <?php
                    echo htmlspecialchars(
                        $_SESSION["student_name"]
                    );
                    ?>,
                    here are the events you joined.
                </p>
            </div>

            <a href="events.php" class="btn">
                Find More Events
            </a>
        </div>

        <?php if ($events->num_rows == 0) { ?>
            <div class="noData">
                You have not joined any events yet.
            </div>
        <?php } else { ?>
            <div class="eventCards">
                <?php while ($event = $events->fetch_assoc()) { ?>
                    <div class="eventCard">
                        <span class="tag">
                            <?php
                            echo htmlspecialchars(
                                $event["category_name"]
                                ?? "General"
                            );
                            ?>
                        </span>

                        <h3>
                            <?php
                            echo htmlspecialchars(
                                $event["title"]
                            );
                            ?>
                        </h3>

                        <div class="eventInfo">
                            <span>
                                📅
                                <?php
                                echo date(
                                    "d M Y",
                                    strtotime(
                                        $event["event_date"]
                                    )
                                );
                                ?>
                            </span>

                            <span>
                                🕒
                                <?php
                                echo date(
                                    "g:i A",
                                    strtotime(
                                        $event["start_time"]
                                    )
                                );
                                ?>
                            </span>

                            <span>
                                📍
                                <?php
                                echo htmlspecialchars(
                                    $event["venue"]
                                );
                                ?>
                            </span>
                        </div>

                        <a
                            href="event.php?id=<?php echo $event["id"]; ?>"
                            class="btn btnLight"
                        >
                            View Event
                        </a>
                    </div>
                <?php } ?>
            </div>
        <?php } ?>
    </div>
</section>

<?php include "footer.php"; ?>
