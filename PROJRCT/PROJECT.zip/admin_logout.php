<?php
include "config.php";

unset($_SESSION["admin_id"]);
unset($_SESSION["admin_name"]);

header("Location: admin.php");
exit;
?>
