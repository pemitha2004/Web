<?php
include "config.php";

$id = (int)($_GET["id"] ?? 0);

/* Register or cancel */
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!isset($_SESSION["student_id"])) {
        header("Location: login.php");
        exit;
    }

    $student_id = $_SESSION["student_id"];
    $action = $_POST["action"] ?? "";

    if ($action == "cancel") {
        $conn->query(
            "DELETE FROM registrations
             WHERE event_id = $id
             AND student_id = $student_id"
        );
    } else {
        $conn->query(
            "INSERT IGNORE INTO registrations
             (event_id, student_id)
             VALUES ($id, $student_id)"
        );
    }

    header("Location: event.php?id=$id");
    exit;
}

/* Get event */
$stmt = $conn->prepare(
    "SELECT events.*, categories.name AS category_name
     FROM events
     LEFT JOIN categories
     ON events.category_id = categories.id
     WHERE events.id = ?"
);

$stmt->bind_param("i", $id);
$stmt->execute();

$event = $stmt->get_result()->fetch_assoc();

if (!$event) {
    die("Event not found.");
}

$count = $conn->query(
    "SELECT COUNT(*) AS total
     FROM registrations
     WHERE event_id = $id"
)->fetch_assoc()["total"];

$joined = false;

if (isset($_SESSION["student_id"])) {
    $student_id = $_SESSION["student_id"];

    $check = $conn->query(
        "SELECT id
         FROM registrations
         WHERE event_id = $id
         AND student_id = $student_id"
    );

    $joined = $check->num_rows > 0;
}

$page_title = $event["title"];
include "header.php";
?>

<section class="eventSection">
    <div class="wrap details">
        <div class="infoBox">
            <span class="tag">
                <?php
                echo htmlspecialchars(
                    $event["category_name"] ?? "General"
                );
                ?>
            </span>

            <h1 class="bigTitle">
                <?php echo htmlspecialchars($event["title"]); ?>
            </h1>

            <p class="gray">
                <?php
                echo nl2br(
                    htmlspecialchars($event["description"])
                );
                ?>
            </p>

            <div class="eventInfo">
                <span>
                    📅
                    <?php
                    echo date(
                        "d M Y",
                        strtotime($event["event_date"])
                    );
                    ?>
                </span>

                <span>
                    🕒
                    <?php
                    echo date(
                        "g:i A",
                        strtotime($event["start_time"])
                    );
                    ?>
                </span>

                <span>
                    📍 <?php echo htmlspecialchars($event["venue"]); ?>
                </span>

                <span>
                    👥 <?php echo $count; ?>
                    / <?php echo $event["capacity"]; ?> joined
                </span>
            </div>
        </div>

        <div class="infoBox joinBox">
            <h3>Join This Event</h3>

            <?php if (!isset($_SESSION["student_id"])) { ?>
                <p class="gray">Login first to save your place.</p>
                <a href="login.php" class="btn">Student Login</a>

            <?php } elseif ($joined) { ?>
                <p class="gray">
                    This event is already in your schedule.
                </p>

                <form method="post">
                    <input
                        type="hidden"
                        name="action"
                        value="cancel"
                    >

                    <button class="btn btnLight">
                        Cancel Registration
                    </button>
                </form>

            <?php } elseif ($count >= $event["capacity"]) { ?>
                <div class="message error">
                    This event is full.
                </div>

            <?php } else { ?>
                <p class="gray">
                    Click below to save your place.
                </p>

                <form method="post">
                    <input
                        type="hidden"
                        name="action"
                        value="join"
                    >

                    <button class="btn">
                        Register for Event
                    </button>
                </form>
            <?php } ?>
        </div>
    </div>
</section>

<?php include "footer.php"; ?>
