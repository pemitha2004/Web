<?php
include "config.php";

$announcements = $conn->query(
    "SELECT *
     FROM announcements
     ORDER BY published_at DESC"
);

$page_title = "Announcements";
include "header.php";
?>

<section class="eventSection">
    <div class="wrap">
        <div class="sectionTop">
            <div>
                <span class="tag">Updates</span>
                <h2>Latest Announcements</h2>

                <p class="gray">
                    Updates and notices about upcoming events.
                </p>
            </div>
        </div>

        <div class="eventCards">
            <?php while ($item = $announcements->fetch_assoc()) { ?>
                <div class="eventCard">
                    <span class="tag">
                        <?php
                        echo date(
                            "d M Y",
                            strtotime($item["published_at"])
                        );
                        ?>
                    </span>

                    <h3>
                        <?php
                        echo htmlspecialchars(
                            $item["title"]
                        );
                        ?>
                    </h3>

                    <p class="gray">
                        <?php
                        echo nl2br(
                            htmlspecialchars($item["message"])
                        );
                        ?>
                    </p>
                </div>
            <?php } ?>
        </div>
    </div>
</section>

<?php include "footer.php"; ?>
