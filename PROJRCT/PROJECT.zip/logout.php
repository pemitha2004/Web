<?php
include "config.php";

unset($_SESSION["student_id"]);
unset($_SESSION["student_name"]);

header("Location: index.php");
exit;
?>
