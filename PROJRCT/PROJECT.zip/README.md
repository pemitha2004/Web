# NSBM EventHub - Clean VIVA Version

This version keeps the existing EventHub UI but makes the PHP files
cleaner and easier to explain during the VIVA.

## Setup

1. Copy the files to:

   D:\xampp\htdocs\nsbm

2. Start Apache and MySQL in XAMPP.

3. Import `database.sql` using phpMyAdmin.

4. Open:

   http://localhost/nsbm/

5. Admin login:

   http://localhost/nsbm/admin.php

   Email: admin@eventhub.com
   Password: admin123

## Main simplification

`event_action.php` was removed.

`event.php` now both:
- displays the event
- handles register/cancel

Admin CRUD is also grouped into simple pages:
- `admin/events.php`
- `admin/categories.php`
- `admin/announcements.php`
