</main>

<footer class="footer">
    <div class="wrap footerRow">
        <div>
            <h3>NSBM EventHub</h3>
            <p>A simple place to discover and join campus events.</p>
        </div>

        <div class="footerRight">
            <p>Web and Mobile Application Development</p>
            <p>Batch 26.1</p>
        </div>
    </div>
</footer>

<script src="js/script.js"></script>
</body>
</html>
