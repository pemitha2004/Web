<?php
include "config.php";

$search = trim($_GET["search"] ?? "");
$category = (int)($_GET["category"] ?? 0);

$categories = $conn->query(
    "SELECT * FROM categories ORDER BY name"
);

$sql = "
    SELECT events.*, categories.name AS category_name
    FROM events
    LEFT JOIN categories
    ON events.category_id = categories.id
    WHERE events.status = 'Published'
    AND events.event_date >= CURDATE()
";

if ($search != "") {
    $safe_search = $conn->real_escape_string($search);

    $sql .= "
        AND (
            events.title LIKE '%$safe_search%'
            OR events.venue LIKE '%$safe_search%'
        )
    ";
}

if ($category > 0) {
    $sql .= " AND events.category_id = $category";
}

$sql .= " ORDER BY events.event_date";

$events = $conn->query($sql);

$page_title = "Events";
include "header.php";
?>

<section class="eventSection">
    <div class="wrap">
        <div class="sectionTop">
            <div>
                <span class="tag">Events</span>
                <h2>Find an Event</h2>
                <p class="gray">Search by name, place or category.</p>
            </div>
        </div>

        <form method="get" class="searchArea">
            <input
                type="text"
                name="search"
                placeholder="Search events..."
                value="<?php echo htmlspecialchars($search); ?>"
            >

            <select name="category">
                <option value="0">All Categories</option>

                <?php while ($cat = $categories->fetch_assoc()) { ?>
                    <option
                        value="<?php echo $cat["id"]; ?>"
                        <?php if ($category == $cat["id"]) echo "selected"; ?>
                    >
                        <?php echo htmlspecialchars($cat["name"]); ?>
                    </option>
                <?php } ?>
            </select>

            <button class="btn">Search</button>
        </form>

        <div class="eventCards">
            <?php while ($event = $events->fetch_assoc()) { ?>
                <div class="eventCard">
                    <span class="tag">
                        <?php
                        echo htmlspecialchars(
                            $event["category_name"] ?? "General"
                        );
                        ?>
                    </span>

                    <h3>
                        <?php echo htmlspecialchars($event["title"]); ?>
                    </h3>

                    <p class="gray">
                        <?php
                        echo htmlspecialchars(
                            substr($event["description"], 0, 120)
                        );
                        ?>...
                    </p>

                    <div class="eventInfo">
                        <span>
                            📅
                            <?php
                            echo date(
                                "d M Y",
                                strtotime($event["event_date"])
                            );
                            ?>
                        </span>

                        <span>
                            🕒
                            <?php
                            echo date(
                                "g:i A",
                                strtotime($event["start_time"])
                            );
                            ?>
                        </span>

                        <span>
                            📍 <?php echo htmlspecialchars($event["venue"]); ?>
                        </span>
                    </div>

                    <a
                        href="event.php?id=<?php echo $event["id"]; ?>"
                        class="btn btnLight"
                    >
                        View Details
                    </a>
                </div>
            <?php } ?>
        </div>
    </div>
</section>

<?php include "footer.php"; ?>
