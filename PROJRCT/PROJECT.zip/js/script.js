function showMenu() {
    document.getElementById("links").classList.toggle("show");
}

function confirmDelete() {
    return confirm("Are you sure you want to delete this?");
}
