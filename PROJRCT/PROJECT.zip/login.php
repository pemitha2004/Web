<?php
include "config.php";

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST["email"]);
    $password = $_POST["password"];

    $stmt = $conn->prepare(
        "SELECT * FROM students WHERE email = ?"
    );

    $stmt->bind_param("s", $email);
    $stmt->execute();

    $student = $stmt->get_result()->fetch_assoc();

    if (
        $student &&
        password_verify($password, $student["password"])
    ) {
        $_SESSION["student_id"] = $student["id"];
        $_SESSION["student_name"] = $student["name"];

        header("Location: index.php");
        exit;
    }

    $message = "Incorrect email or password.";
}

$page_title = "Student Login";
include "header.php";
?>

<div class="wrap">
    <div class="formArea">
        <span class="tag">Student Login</span>
        <h2>Welcome Back</h2>

        <p class="gray">
            Login to join events and view your schedule.
        </p>

        <?php if (isset($_GET["created"])) { ?>
            <div class="message success">
                Account created. You can login now.
            </div>
        <?php } ?>

        <?php if ($message != "") { ?>
            <div class="message error">
                <?php echo htmlspecialchars($message); ?>
            </div>
        <?php } ?>

        <form method="post">
            <div class="inputBox">
                <label>Email Address</label>
                <input type="email" name="email" required>
            </div>

            <div class="inputBox">
                <label>Password</label>
                <input type="password" name="password" required>
            </div>

            <button class="btn">Login</button>
        </form>
    </div>
</div>

<?php include "footer.php"; ?>
