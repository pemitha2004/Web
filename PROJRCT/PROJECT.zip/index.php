<?php
include "config.php";

$event_count = $conn->query(
    "SELECT COUNT(*) AS total
     FROM events
     WHERE status = 'Published'
     AND event_date >= CURDATE()"
)->fetch_assoc()["total"];

$student_count = $conn->query(
    "SELECT COUNT(*) AS total FROM students"
)->fetch_assoc()["total"];

$join_count = $conn->query(
    "SELECT COUNT(*) AS total FROM registrations"
)->fetch_assoc()["total"];

$events = $conn->query(
    "SELECT events.*, categories.name AS category_name
     FROM events
     LEFT JOIN categories
     ON events.category_id = categories.id
     WHERE events.status = 'Published'
     AND events.event_date >= CURDATE()
     ORDER BY events.event_date
     LIMIT 3"
);

$page_title = "NSBM EventHub";
include "header.php";
?>

<section class="home">
    <div class="wrap homeRow">
        <div>
            <span class="smallTitle">NSBM Campus Events</span>
            <h1>See what’s happening around campus.</h1>

            <p>
                Find upcoming university events, save your place
                and keep your plans together in one easy place.
            </p>

            <div class="homeButtons">
                <a href="events.php" class="btn">See Events</a>

                <?php if (!isset($_SESSION["student_id"])) { ?>
                    <a href="register.php" class="btn btnLight">
                        Create Account
                    </a>
                <?php } ?>
            </div>
        </div>

        <div class="homeInfo">
            <h3>EventHub Today</h3>
            <p class="gray">A quick look at what is happening.</p>

            <div class="quickLine">
                <span>Upcoming events</span>
                <strong><?php echo $event_count; ?></strong>
            </div>

            <div class="quickLine">
                <span>Students</span>
                <strong><?php echo $student_count; ?></strong>
            </div>

            <div class="quickLine">
                <span>Registrations</span>
                <strong><?php echo $join_count; ?></strong>
            </div>
        </div>
    </div>
</section>

<section class="eventSection">
    <div class="wrap">
        <div class="numberRow">
            <div class="numberBox">
                <p>Upcoming Events</p>
                <h2><?php echo $event_count; ?></h2>
            </div>

            <div class="numberBox">
                <p>Students</p>
                <h2><?php echo $student_count; ?></h2>
            </div>

            <div class="numberBox">
                <p>Registrations</p>
                <h2><?php echo $join_count; ?></h2>
            </div>

            <div class="numberBox">
                <p>Account Types</p>
                <h2>2</h2>
            </div>
        </div>

        <div class="sectionTop">
            <div>
                <span class="tag">Coming Up</span>
                <h2>Upcoming Events</h2>
                <p class="gray">A few events you may want to join.</p>
            </div>

            <a href="events.php" class="btn btnLight">View All</a>
        </div>

        <div class="eventCards">
            <?php while ($event = $events->fetch_assoc()) { ?>
                <div class="eventCard">
                    <span class="tag">
                        <?php
                        echo htmlspecialchars(
                            $event["category_name"] ?? "General"
                        );
                        ?>
                    </span>

                    <h3>
                        <?php echo htmlspecialchars($event["title"]); ?>
                    </h3>

                    <p class="gray">
                        <?php
                        echo htmlspecialchars(
                            substr($event["description"], 0, 110)
                        );
                        ?>...
                    </p>

                    <div class="eventInfo">
                        <span>
                            📅
                            <?php
                            echo date(
                                "d M Y",
                                strtotime($event["event_date"])
                            );
                            ?>
                        </span>

                        <span>
                            🕒
                            <?php
                            echo date(
                                "g:i A",
                                strtotime($event["start_time"])
                            );
                            ?>
                        </span>

                        <span>
                            📍 <?php echo htmlspecialchars($event["venue"]); ?>
                        </span>
                    </div>

                    <a
                        href="event.php?id=<?php echo $event["id"]; ?>"
                        class="btn btnLight"
                    >
                        View Event
                    </a>
                </div>
            <?php } ?>
        </div>
    </div>
</section>

<?php include "footer.php"; ?>
