<?php
$page_title = $page_title ?? "NSBM EventHub";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($page_title); ?></title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<header class="top">
    <div class="wrap nav">
        <a href="index.php" class="brand">
            <span class="brandIcon">E</span>
            <span>NSBM EventHub</span>
        </a>

        <button class="menuBtn" onclick="showMenu()">☰</button>

        <nav id="links">
            <a href="index.php">Home</a>
            <a href="events.php">Events</a>
            <a href="announcements.php">Announcements</a>

            <?php if (isset($_SESSION["student_id"])) { ?>
                <a href="my_schedule.php">My Schedule</a>
                <a href="logout.php">Logout</a>
            <?php } else { ?>
                <a href="login.php">Student Login</a>
                <a href="register.php" class="greenLink">Register</a>
            <?php } ?>

            <a href="admin.php" class="adminLink">Admin</a>
        </nav>
    </div>
</header>

<main>
