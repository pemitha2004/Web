DROP DATABASE IF EXISTS nsbm_eventhub;

CREATE DATABASE nsbm_eventhub;
USE nsbm_eventhub;

CREATE TABLE students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL
);

CREATE TABLE admins (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL
);

CREATE TABLE categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL
);

CREATE TABLE events (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category_id INT,
    title VARCHAR(150) NOT NULL,
    description TEXT NOT NULL,
    event_date DATE NOT NULL,
    start_time TIME NOT NULL,
    venue VARCHAR(150) NOT NULL,
    capacity INT NOT NULL DEFAULT 100,
    status VARCHAR(20) NOT NULL DEFAULT 'Published',

    FOREIGN KEY (category_id)
    REFERENCES categories(id)
    ON DELETE SET NULL
);

CREATE TABLE registrations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    event_id INT NOT NULL,
    student_id INT NOT NULL,
    registered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    UNIQUE (event_id, student_id),

    FOREIGN KEY (event_id)
    REFERENCES events(id)
    ON DELETE CASCADE,

    FOREIGN KEY (student_id)
    REFERENCES students(id)
    ON DELETE CASCADE
);

CREATE TABLE announcements (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(150) NOT NULL,
    message TEXT NOT NULL,
    published_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO admins (
    name,
    email,
    password
)
VALUES (
    'EventHub Administrator',
    'admin@eventhub.com',
    '$2y$12$8QB1e5C0SX4fcobwknjj0edRDcVdE.hqnGP5TMtzdFqzYsclTmEiG'
);

INSERT INTO categories (name)
VALUES
    ('Academic'),
    ('Clubs & Societies'),
    ('Sports'),
    ('Career'),
    ('Entertainment');

INSERT INTO events (
    category_id,
    title,
    description,
    event_date,
    start_time,
    venue,
    capacity,
    status
)
VALUES
(
    2,
    'Innovation Club Meetup',
    'Meet students interested in technology, design and startup ideas.',
    DATE_ADD(CURDATE(), INTERVAL 7 DAY),
    '15:30:00',
    'Faculty of Computing - Lab 02',
    80,
    'Published'
),
(
    4,
    'Career Readiness Workshop',
    'A workshop about CV writing, LinkedIn and interview preparation.',
    DATE_ADD(CURDATE(), INTERVAL 10 DAY),
    '10:00:00',
    'NSBM Auditorium',
    150,
    'Published'
),
(
    3,
    'Inter Faculty Futsal',
    'A student futsal event for teams and spectators.',
    DATE_ADD(CURDATE(), INTERVAL 14 DAY),
    '16:00:00',
    'NSBM Sports Ground',
    200,
    'Published'
);

INSERT INTO announcements (
    title,
    message
)
VALUES
(
    'Welcome to NSBM EventHub',
    'Students can browse events, register online and view their schedule.'
),
(
    'Event Registration Reminder',
    'Some events have limited spaces, so register early.'
);
